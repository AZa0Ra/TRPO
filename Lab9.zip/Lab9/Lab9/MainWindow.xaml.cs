﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace Lab9
{
    public partial class MainWindow : Window
    {
        private const int TOTAL_SPACES = 100;
        private bool[] parkingSensor;
        private object logLock = new object();
        private List<string> logs = new List<string>();

        public MainWindow()
        {
            InitializeComponent();
            parkingSensor = new bool[TOTAL_SPACES];

            Task.Run(() => ParallelSensorReading());
            Task.Run(() => StartLogging());
            Task.Run(() => ClearLogging());
        }

        private async Task ParallelSensorReading()
        {
            var tasks = new Task[TOTAL_SPACES];
            Random rand = new Random();

            for (int i = 0; i < TOTAL_SPACES; i++)
            {
                int index = i;
                int delay = rand.Next(100, 300);
                await Task.Delay(delay);

                tasks[i] = Task.Run(() => SimulateSensorReading(index));
            }

            await Task.WhenAll(tasks);
        }

        private async Task SimulateSensorReading(int index)
        {
            Random rand = new Random();

            while (true)
            {
                int delay = rand.Next(100, 300);
                await Task.Delay(delay);

                parkingSensor[index] = !parkingSensor[index];

                await Task.Delay(1000);

                UpdateParkingStatus();
            }
        }

        private void UpdateParkingStatus()
        {
            int occupiedCount = parkingSensor.Count(s => s);
            int freeCount = TOTAL_SPACES - occupiedCount;
            double occupancyRate = (double)occupiedCount / TOTAL_SPACES * 100;

            Dispatcher.Invoke(() =>
            {
                FreeSpacesText.Text = $"Free Spaces: {freeCount}";
                OccupancyText.Text = $"Occupancy: {occupancyRate:F2}%";

                if (occupancyRate > 80)
                {
                    WarningText.Visibility = Visibility.Visible;
                }
                else
                {
                    WarningText.Visibility = Visibility.Hidden;
                }

                if (occupancyRate > 50)
                {
                    LogMessage("Warning: Parking lot occupancy exceeded 50%");
                }
            });
        }

        private void LogMessage(string message)
        {
            lock (logLock)
            {
                logs.Add($"{DateTime.Now}: {message}");
            }
        }

        private async Task StartLogging()
        {
            while (true)
            {
                List<string> currentLogs;
                lock (logLock)
                {
                    currentLogs = new List<string>(logs);
                }
                Dispatcher.Invoke(() =>
                {
                    foreach (var log in currentLogs)
                    {
                        LogListBox.Items.Add(log);
                    }
                });
                await Task.Delay(1000);
            }
        }

        private async Task ClearLogging()
        {
            while (true)
            {
                await Task.Delay(10000);

                Dispatcher.Invoke(() =>
                {
                    LogListBox.Items.Clear();
                });

                lock (logLock)
                {
                    logs.Clear();
                }
            }
        }
    }
}
